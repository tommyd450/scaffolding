# Important Notice

This is a fork of the `encoding/asn1` Go package. The original source can be found on
[GitHub](https://github.com/golang/go).

Be careful about making local modifications to this code as it will
make maintenance harder in future.
